package Ch05;

import lombok.Data;

@Data
public class TestBean
{
    private String msg1;
    private String msg2;
    private String msg3;
}
