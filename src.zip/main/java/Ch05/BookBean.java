package Ch05;

import lombok.Data;

@Data
public class BookBean
{
    private String Bookcode;
    private String Bookname;
    private String Bookprice;
}
